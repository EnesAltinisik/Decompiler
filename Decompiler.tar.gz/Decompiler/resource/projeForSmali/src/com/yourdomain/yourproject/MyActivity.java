package com.yourdomain.yourproject;
 import android.app.Activity;
 import android.os.Bundle;
 public class MyActivity extends Activity {  
public    void s(){
  
}
}