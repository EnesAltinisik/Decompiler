package jadx.core.dex.regions.loops;

public abstract class LoopType {
}
