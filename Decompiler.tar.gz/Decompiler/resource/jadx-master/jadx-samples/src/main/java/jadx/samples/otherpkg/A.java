package jadx.samples.otherpkg;

public class A {
	protected class B {

	}
}
