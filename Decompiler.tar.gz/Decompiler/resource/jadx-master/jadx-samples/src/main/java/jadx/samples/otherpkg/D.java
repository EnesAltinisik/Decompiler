package jadx.samples.otherpkg;

public class D {
	public static class E {

	}
}
